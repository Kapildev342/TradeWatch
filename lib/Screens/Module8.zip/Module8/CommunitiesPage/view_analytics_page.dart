import 'package:flutter/material.dart';

class ViewAnalyticsPage extends StatefulWidget {
  const ViewAnalyticsPage({super.key});

  @override
  State<ViewAnalyticsPage> createState() => _ViewAnalyticsPageState();
}

class _ViewAnalyticsPageState extends State<ViewAnalyticsPage> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Container(),
      ),
    );
  }
}
